/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jimcom;

import Java.ScrollBarCustom;
import TableClass.TableCustom;
import java.awt.Color;
import java.awt.Font;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.Date;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttribute;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.OrientationRequested;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Mr.Phiphat
 */
public class PrintPDF extends javax.swing.JFrame {
    
    public PrintPDF(JTable table,String namesupplier,String discount,String detail) {
        initComponents();
        DefaultTableModel model = (DefaultTableModel) TableProduct.getModel();
        model.setRowCount(0); // เคลียร์ข้อมูลทั้งหมดใน JTable
        ScrollBarCustom sp = new ScrollBarCustom();
        sp.setOrientation(JScrollBar.HORIZONTAL);
        ScrollProducts.setVerticalScrollBar(new ScrollBarCustom());
        ScrollProducts.setHorizontalScrollBar(sp);
        ScrollProducts.getViewport().setBackground(Color.WHITE);
        TableProduct.getTableHeader().setFont(new Font("Poppins", Font.PLAIN, 10));
        TableCustom.apply(ScrollProducts, TableCustom.TableType.MULTI_LINE);
        
        DefaultTableModel model1 = (DefaultTableModel) table.getModel();
        DefaultTableModel model2 = (DefaultTableModel) TableProduct.getModel();

        int rowCount = model1.getRowCount();
        int columnCount = model1.getColumnCount();

        for (int i = 0; i < rowCount; i++) {
            Object[] rowData = new Object[columnCount];
            for (int j = 0; j < columnCount; j++) {
                rowData[j] = model1.getValueAt(i, j);
            }
            model2.addRow(rowData);
        }
        
        
        jimcom.setText("<html>Jimcom 38/48,<br>Pruksa Village 119,<br>Khlong Song Subdistrict,<br>Khlong Luang District,<br>Pathum Thani 12120</html>");

        LocalDate currentDate = LocalDate.now();
        date.setText(currentDate.toString());
        
        this.discount.setText(discount);
        Orderto.setText(namesupplier);
        
        int total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            int rowTotal = Integer.parseInt(model2.getValueAt(i, 4).toString());
            total += rowTotal;
        }
        
        int calcula = (total * 7 / 100) + total - Integer.parseInt(this.discount.getText());
        int vate = (total * 7 / 100) ;
        tax1.setText(String.valueOf(calcula));
        tax.setText(String.valueOf(vate));
        note.setText(detail);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jimcom = new javax.swing.JLabel();
        discount = new javax.swing.JLabel();
        tax = new javax.swing.JLabel();
        tax1 = new javax.swing.JLabel();
        Orderto = new javax.swing.JLabel();
        note = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        ScrollProducts = new javax.swing.JScrollPane();
        TableProduct = new javax.swing.JTable();
        BG = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Print1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jimcom.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jPanel1.add(jimcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 140, 80));

        discount.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        discount.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        discount.setText("4500");
        discount.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(discount, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 568, 220, -1));

        tax.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        tax.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tax.setText("4500");
        tax.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(tax, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 590, 220, -1));

        tax1.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        tax1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tax1.setText("4500");
        tax1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(tax1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 634, 220, -1));

        Orderto.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        Orderto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Orderto.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(Orderto, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 130, 90));

        note.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        note.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        note.setText("Details");
        note.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(note, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 575, 250, 60));

        date.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jPanel1.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(512, 187, 70, 10));

        ScrollProducts.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        ScrollProducts.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        TableProduct.setFont(new java.awt.Font("Poppins Light", 0, 8)); // NOI18N
        TableProduct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "QTY", "PRODUCT", "DETAILS", " PRICE", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableProduct.setRowHeight(40);
        ScrollProducts.setViewportView(TableProduct);
        if (TableProduct.getColumnModel().getColumnCount() > 0) {
            TableProduct.getColumnModel().getColumn(0).setPreferredWidth(10);
        }

        jPanel1.add(ScrollProducts, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 268, 560, 275));

        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pageOrder/Purchase_Order_JIMCOM-2.png"))); // NOI18N
        jPanel1.add(BG, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 0, 590, -1));
        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 150, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Print1.setText("Print");
        Print1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Print1ActionPerformed(evt);
            }
        });
        getContentPane().add(Print1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 780, 113, 40));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Print1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Print1ActionPerformed
        PanelPrinter panelPrinter = new PanelPrinter(jPanel1);
        panelPrinter.printPanel();
    }//GEN-LAST:event_Print1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrintPDF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrintPDF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrintPDF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrintPDF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

//                new PrintPDF().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JLabel Orderto;
    private javax.swing.JButton Print1;
    private javax.swing.JScrollPane ScrollProducts;
    private javax.swing.JTable TableProduct;
    private javax.swing.JLabel date;
    private javax.swing.JLabel discount;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jimcom;
    private javax.swing.JLabel note;
    private javax.swing.JLabel tax;
    private javax.swing.JLabel tax1;
    // End of variables declaration//GEN-END:variables
}
