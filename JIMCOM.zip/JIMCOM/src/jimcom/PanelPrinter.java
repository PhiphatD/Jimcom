/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jimcom;

import java.awt.*;
import java.awt.print.*;
import javax.swing.*;

public class PanelPrinter implements Printable {
    private JPanel panelToPrint;

    public PanelPrinter(JPanel panel) {
        this.panelToPrint = panel;
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int pageIndex) throws PrinterException {
        if (pageIndex > 0) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        // พิมพ์เนื้อหาใน JPanel ลงบนกระดาษ
        panelToPrint.print(g);

        return PAGE_EXISTS;
    }

    public void printPanel() {
         PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(this);

        // สร้าง PageFormat เพื่อตั้งค่าขนาดกระดาษเป็น A4
        PageFormat pf = job.defaultPage();
        Paper paper = new Paper();
        double width = 8.27 * 72; // ขนาด A4 ความกว้าง 8.27 นิ้ว
        double height = 11.69 * 72; // ขนาด A4 ความสูง 11.69 นิ้ว
        paper.setSize(width, height);
        paper.setImageableArea(0, 0, width, height);
        pf.setPaper(paper);
        job.setPrintable(this, pf);

        // แสดงตัวเลือกการพิมพ์และทำการพิมพ์
        boolean doPrint = job.printDialog();
        if (doPrint) {
            try {
                job.print();
            } catch (PrinterException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        // สร้าง JPanel ที่มี JTable ภายใน
        JPanel panel = new JPanel();
        JTable table = new JTable(10, 5); // สร้าง JTable ตัวอย่าง (10 แถว 5 คอลัมน์)
        panel.add(new JScrollPane(table));

        // สร้าง PanelPrinter และทำการพิมพ์
        PanelPrinter panelPrinter = new PanelPrinter(panel);
        panelPrinter.printPanel();
    }
}
