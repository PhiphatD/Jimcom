/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/MDIApplication.java to edit this template
 */
package jimcom;

import Java.ScrollBarCustom;
import Java.TableActionCellEditor;
import Java.TableActionCellRender;
import Java.TableActionEvent;
import TableClass.TableCustom;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import jdk.jshell.Diag;

/**
 *
 * @author Mr.Phiphat
 */
public class MainJimcom extends javax.swing.JFrame {
    private static MainJimcom instance = null;
    List<List<String>> dataSupplier = new ArrayList<>();
    
    public static MainJimcom getInstane() {
        if (instance == null) {
            instance = new MainJimcom();
        }
        return instance;
    }
    public void setUpdatproduct(){
        
        DefaultTableModel model = (DefaultTableModel) TableProduct.getModel();
        model.setRowCount(0); // เคลียร์ข้อมูลทั้งหมดใน JTable
        
        String fileData = ProductDB.readDataFromFile();
        String[] products = fileData.split("\n");

        for (String product : products) {
            String[] rowData = product.split(",");
            model.addRow(rowData); // เพิ่มแถวใหม่ลงใน JTable โดยใช้ข้อมูลใน rowData
        }
    }
    /**
     * Creates new form MainJimcom
     */
    public MainJimcom() {
        setUndecorated(true);
        initComponents();
        setPreferredSize(new Dimension(1536, 864)); // กำหนดขนาด JFrame เป็น 800x600 pixels
        this.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        TableProduct.getTableHeader().setFont(new Font("poppins", Font.BOLD, 12)); 
        TableCustom.apply(ScrollProducts, TableCustom.TableType.MULTI_LINE);

        ScrollBarCustom sp = new ScrollBarCustom();
        sp.setOrientation(JScrollBar.HORIZONTAL);
        ScrollProducts.setVerticalScrollBar(new ScrollBarCustom());
        ScrollProducts.setHorizontalScrollBar(sp);
        ScrollProducts.getViewport().setBackground(Color.WHITE);
        
        getContentPane().setBackground(Color.white);
        
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                System.out.println("Edit row : " + row);
                  String warning = "Edit Product";
                  int columnCount = TableProduct.getColumnCount(); // หาจำนวนคอลัมน์ในตาราง
                  DefaultTableModel model = (DefaultTableModel) TableProduct.getModel(); // ดึงโมเดลของตาราง
                  
                  Object name = model.getValueAt(row, 1);
                  Object  price  = model.getValueAt(row, 2);
                  Object type = model.getValueAt(row, 3);
                  Object details = model.getValueAt(row, 4);
                  
                  JDialogAddEdit add = new JDialogAddEdit(name.toString(), type.toString(), price.toString(), details.toString(),warning,row+1);
                  add.setVisible(true);
            }

            @Override
            public void onDelete(int row) {
                if (TableProduct.isEditing()) {
                    TableProduct.getCellEditor().stopCellEditing();
                }
//                DefaultTableModel model = (DefaultTableModel) TableProduct.getModel();
//                model.removeRow(row);
                DefaultTableModel model = (DefaultTableModel) TableProduct.getModel(); // ดึงโมเดลของตาราง
                  
                  Object name = model.getValueAt(row, 1);
                  Object  price  = model.getValueAt(row, 2);
                  Object type = model.getValueAt(row, 3);
                  Object details = model.getValueAt(row, 4);
                  
                DialogDelect del = new DialogDelect(row, name.toString(), type.toString(), price.toString(), details.toString());
                del.setVisible(true);
            }

        };
        
        
        TableProduct.getColumnModel().getColumn(5).setCellRenderer(new TableActionCellRender());
        TableProduct.getColumnModel().getColumn(5).setCellEditor(new TableActionCellEditor(event));
        
        DefaultTableModel model = (DefaultTableModel) TableProduct.getModel();
        model.setRowCount(0); // เคลียร์ข้อมูลทั้งหมดใน JTable

        String fileData = ProductDB.readDataFromFile();
        String[] products = fileData.split("\n");

        for (String product : products) {
            String[] rowData = product.split(",");
            model.addRow(rowData); // เพิ่มแถวใหม่ลงใน JTable โดยใช้ข้อมูลใน rowData
        }
        ChangjPanel(true, false, false);
        Icon icon = new ImageIcon(getClass().getResource("/image/OrderC.png"));
        Oder.setIcon(icon);
    }

    public void ChangjPanel(boolean isProduct,boolean isSupplier,boolean isPurchase){
        JPOrder.setVisible(isProduct);
        JPSupplier.setVisible(isSupplier);
        JPPurchase.setVisible(isPurchase);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ZoneMenu = new javax.swing.JPanel();
        Purchase = new javax.swing.JLabel();
        Supplier = new javax.swing.JLabel();
        Oder = new javax.swing.JLabel();
        Exit = new javax.swing.JLabel();
        Menu = new javax.swing.JLabel();
        JPOrder = new javax.swing.JPanel();
        btnAddProduct = new javax.swing.JLabel();
        ScrollProducts = new javax.swing.JScrollPane();
        TableProduct = new javax.swing.JTable();
        Bgorder = new javax.swing.JLabel();
        JPSupplier = new javax.swing.JPanel();
        ScrollSupplier = new javax.swing.JScrollPane();
        TableSupplier = new javax.swing.JTable();
        btnAddsupplier = new javax.swing.JLabel();
        BGsupplier = new javax.swing.JLabel();
        JPPurchase = new javax.swing.JPanel();
        ADDPURCHASE = new javax.swing.JLabel();
        discount = new javax.swing.JTextField();
        ScrollPuschase = new javax.swing.JScrollPane();
        TablePurchase = new javax.swing.JTable();
        txtTotal = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        txtInclusive = new javax.swing.JLabel();
        combonameSupplier = new ComboboxClass.ComboBoxSuggestion();
        Note = new javax.swing.JTextField();
        jScrollcontact = new javax.swing.JScrollPane();
        contactData = new javax.swing.JTextArea();
        btnpurchase = new javax.swing.JLabel();
        BGpurchase = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ZoneMenu.setOpaque(false);
        ZoneMenu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Purchase.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Purchase.png"))); // NOI18N
        Purchase.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Purchase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PurchaseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PurchaseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PurchaseMouseExited(evt);
            }
        });
        ZoneMenu.add(Purchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, -1, -1));

        Supplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Supplier.png"))); // NOI18N
        Supplier.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Supplier.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SupplierMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SupplierMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SupplierMouseExited(evt);
            }
        });
        ZoneMenu.add(Supplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 329, -1, -1));

        Oder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Order.png"))); // NOI18N
        Oder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Oder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OderMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                OderMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                OderMouseExited(evt);
            }
        });
        ZoneMenu.add(Oder, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 243, -1, -1));

        Exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Exit.png"))); // NOI18N
        Exit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitMouseExited(evt);
            }
        });
        ZoneMenu.add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 778, -1, -1));

        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Menu.png"))); // NOI18N
        ZoneMenu.add(Menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, -1));

        getContentPane().add(ZoneMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, 870));

        JPOrder.setBackground(new java.awt.Color(240, 240, 240));
        JPOrder.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAddProduct.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnaddproduc.png"))); // NOI18N
        btnAddProduct.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAddProduct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAddProductMouseClicked(evt);
            }
        });
        JPOrder.add(btnAddProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 60, -1, -1));

        TableProduct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "PRODUCTS", "PRICE", "TPYE", "PRODUCTS DETAILS", "ACTIONS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableProduct.setRowHeight(40);
        ScrollProducts.setViewportView(TableProduct);
        if (TableProduct.getColumnModel().getColumnCount() > 0) {
            TableProduct.getColumnModel().getColumn(0).setPreferredWidth(40);
            TableProduct.getColumnModel().getColumn(1).setPreferredWidth(100);
            TableProduct.getColumnModel().getColumn(2).setMinWidth(50);
            TableProduct.getColumnModel().getColumn(2).setPreferredWidth(100);
            TableProduct.getColumnModel().getColumn(3).setMinWidth(30);
            TableProduct.getColumnModel().getColumn(3).setPreferredWidth(80);
            TableProduct.getColumnModel().getColumn(4).setPreferredWidth(80);
            TableProduct.getColumnModel().getColumn(5).setPreferredWidth(40);
        }

        JPOrder.add(ScrollProducts, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 1040, 680));

        Bgorder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Bgorder.png"))); // NOI18N
        JPOrder.add(Bgorder, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1270, -1));

        getContentPane().add(JPOrder, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 1270, 860));

        JPSupplier.setBackground(new java.awt.Color(255, 255, 255));
        JPSupplier.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableSupplier.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Date", "SUPPLIER", "CONTACT PERSON", "TELL", "EMAIL", "FAX", "ADDRESS", "ACTIONS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableSupplier.setRowHeight(40);
        ScrollSupplier.setViewportView(TableSupplier);
        if (TableSupplier.getColumnModel().getColumnCount() > 0) {
            TableSupplier.getColumnModel().getColumn(0).setPreferredWidth(120);
            TableSupplier.getColumnModel().getColumn(0).setMaxWidth(120);
            TableSupplier.getColumnModel().getColumn(1).setPreferredWidth(70);
            TableSupplier.getColumnModel().getColumn(2).setMinWidth(50);
            TableSupplier.getColumnModel().getColumn(2).setPreferredWidth(200);
            TableSupplier.getColumnModel().getColumn(2).setMaxWidth(200);
            TableSupplier.getColumnModel().getColumn(3).setMinWidth(0);
            TableSupplier.getColumnModel().getColumn(3).setPreferredWidth(160);
            TableSupplier.getColumnModel().getColumn(3).setMaxWidth(160);
            TableSupplier.getColumnModel().getColumn(4).setPreferredWidth(160);
            TableSupplier.getColumnModel().getColumn(4).setMaxWidth(160);
            TableSupplier.getColumnModel().getColumn(5).setPreferredWidth(80);
            TableSupplier.getColumnModel().getColumn(6).setPreferredWidth(200);
            TableSupplier.getColumnModel().getColumn(7).setPreferredWidth(100);
            TableSupplier.getColumnModel().getColumn(7).setMaxWidth(100);
        }

        JPSupplier.add(ScrollSupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 1120, 680));

        btnAddsupplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/supplier/btnSupplier.png"))); // NOI18N
        btnAddsupplier.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAddsupplier.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAddsupplierMouseClicked(evt);
            }
        });
        JPSupplier.add(btnAddsupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(1084, 60, 110, -1));

        BGsupplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/supplier/BG.png"))); // NOI18N
        JPSupplier.add(BGsupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1270, -1));

        getContentPane().add(JPSupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 1270, 860));

        JPPurchase.setBackground(new java.awt.Color(255, 255, 255));
        JPPurchase.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ADDPURCHASE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/supplier/btnaddpurchase.png"))); // NOI18N
        ADDPURCHASE.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ADDPURCHASE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ADDPURCHASEMouseClicked(evt);
            }
        });
        JPPurchase.add(ADDPURCHASE, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 133, 180, -1));

        discount.setBackground(new java.awt.Color(221, 221, 221));
        discount.setFont(new java.awt.Font("Poppins Medium", 0, 18)); // NOI18N
        discount.setForeground(new java.awt.Color(105, 105, 105));
        discount.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        discount.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        JPPurchase.add(discount, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 502, 170, 50));

        TablePurchase.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "QTY", "PRODUCT", "DETAILS", "PRICE", "TOTAL", "ACTION"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablePurchase.setRowHeight(40);
        ScrollPuschase.setViewportView(TablePurchase);
        if (TablePurchase.getColumnModel().getColumnCount() > 0) {
            TablePurchase.getColumnModel().getColumn(0).setPreferredWidth(120);
            TablePurchase.getColumnModel().getColumn(0).setMaxWidth(120);
            TablePurchase.getColumnModel().getColumn(1).setPreferredWidth(70);
            TablePurchase.getColumnModel().getColumn(2).setMinWidth(50);
            TablePurchase.getColumnModel().getColumn(2).setPreferredWidth(200);
            TablePurchase.getColumnModel().getColumn(2).setMaxWidth(200);
            TablePurchase.getColumnModel().getColumn(3).setMinWidth(0);
            TablePurchase.getColumnModel().getColumn(3).setPreferredWidth(160);
            TablePurchase.getColumnModel().getColumn(3).setMaxWidth(160);
            TablePurchase.getColumnModel().getColumn(4).setPreferredWidth(160);
            TablePurchase.getColumnModel().getColumn(4).setMaxWidth(160);
            TablePurchase.getColumnModel().getColumn(5).setPreferredWidth(100);
            TablePurchase.getColumnModel().getColumn(5).setMaxWidth(100);
        }

        JPPurchase.add(ScrollPuschase, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 1130, 250));

        txtTotal.setFont(new java.awt.Font("Poppins Medium", 0, 18)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(102, 102, 102));
        txtTotal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTotal.setText("0.00");
        JPPurchase.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 625, 170, 60));

        date.setFont(new java.awt.Font("Poppins SemiBold", 0, 18)); // NOI18N
        date.setText("jLabel1");
        JPPurchase.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 80, 140, 40));

        txtInclusive.setFont(new java.awt.Font("Poppins Medium", 0, 18)); // NOI18N
        txtInclusive.setForeground(new java.awt.Color(102, 102, 102));
        txtInclusive.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtInclusive.setText("7 %");
        JPPurchase.add(txtInclusive, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 565, 170, 60));

        combonameSupplier.setBorder(null);
        JPPurchase.add(combonameSupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(274, 497, 267, 40));

        Note.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        Note.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Note.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoteActionPerformed(evt);
            }
        });
        JPPurchase.add(Note, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 690, 560, 50));

        jScrollcontact.setBorder(null);

        contactData.setEditable(false);
        contactData.setBackground(new java.awt.Color(255, 255, 255));
        contactData.setColumns(20);
        contactData.setRows(5);
        jScrollcontact.setViewportView(contactData);

        JPPurchase.add(jScrollcontact, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 575, 560, 70));

        btnpurchase.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/supplier/btnPurchase.png"))); // NOI18N
        btnpurchase.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnpurchase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnpurchaseMouseClicked(evt);
            }
        });
        JPPurchase.add(btnpurchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 710, -1, -1));

        BGpurchase.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/supplier/purchaseBg.png"))); // NOI18N
        JPPurchase.add(BGpurchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        getContentPane().add(JPPurchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 1270, 860));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseEntered
        Icon icon = new ImageIcon(getClass().getResource("/image/ExitEn.png"));
        Exit.setIcon(icon);
    }//GEN-LAST:event_ExitMouseEntered

    private void ExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseExited
        Icon icon = new ImageIcon(getClass().getResource("/image/Exit.png"));
        Exit.setIcon(icon);
    }//GEN-LAST:event_ExitMouseExited

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
        dispose();
        System.exit(0);
    }//GEN-LAST:event_ExitMouseClicked

    private void PurchaseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PurchaseMouseEntered
        Icon ulicon = Purchase.getIcon();
        String uliconURL = ulicon.toString();
        
        Icon normal = new ImageIcon(getClass().getResource("/image/Purchase.png"));
        Icon click = new ImageIcon(getClass().getResource("/image/PurchaseC.png"));
        Icon en = new ImageIcon(getClass().getResource("/image/PurchaseEn.png"));
        
        if (uliconURL.equals(click.toString())) {
            System.out.println("Ok");
        } else {
            Purchase.setIcon(en);
        }
    }//GEN-LAST:event_PurchaseMouseEntered

    private void PurchaseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PurchaseMouseExited
        Icon ulicon = Purchase.getIcon();
        String uliconURL = ulicon.toString();
        
        Icon normal = new ImageIcon(getClass().getResource("/image/Purchase.png"));
        Icon click = new ImageIcon(getClass().getResource("/image/PurchaseC.png"));
        Icon en = new ImageIcon(getClass().getResource("/image/PurchaseEn.png"));
        
        if (uliconURL.equals(click.toString())) {
            System.out.println("Ok");
        } else {
            Purchase.setIcon(normal);
        }
    }//GEN-LAST:event_PurchaseMouseExited

    private void SupplierMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SupplierMouseEntered
        Icon ulicon = Supplier.getIcon();
        String uliconURL = ulicon.toString();
        
        Icon normal = new ImageIcon(getClass().getResource("/image/Supplier.png"));
        Icon click = new ImageIcon(getClass().getResource("/image/SupplierC.png"));
        Icon en = new ImageIcon(getClass().getResource("/image/SupplierEn.png"));
        
        if (uliconURL.equals(click.toString())) {
            System.out.println("Ok");
        } else {
            Supplier.setIcon(en);
        }
    }//GEN-LAST:event_SupplierMouseEntered

    private void SupplierMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SupplierMouseExited
        Icon ulicon = Supplier.getIcon();
        String uliconURL = ulicon.toString();
        
        Icon normal = new ImageIcon(getClass().getResource("/image/Supplier.png"));
        Icon click = new ImageIcon(getClass().getResource("/image/SupplierC.png"));
        Icon en = new ImageIcon(getClass().getResource("/image/SupplierEn.png"));
        
        if (uliconURL.equals(click.toString())) {
            System.out.println("Ok");
        } else {
            Supplier.setIcon(normal);
        }
    }//GEN-LAST:event_SupplierMouseExited

    private void OderMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OderMouseEntered
        Icon ulicon = Oder.getIcon();
        String uliconURL = ulicon.toString();
        
        Icon normal = new ImageIcon(getClass().getResource("/image/Order.png"));
        Icon click = new ImageIcon(getClass().getResource("/image/OrderC.png"));
        Icon en = new ImageIcon(getClass().getResource("/image/OrderEn.png"));
        
        if (uliconURL.equals(click.toString())) {
            System.out.println("Ok");
        } else {
            Oder.setIcon(en);
        }
    }//GEN-LAST:event_OderMouseEntered

    private void OderMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OderMouseExited

        Icon ulicon = Oder.getIcon();
        String uliconURL = ulicon.toString();
        
        Icon normal = new ImageIcon(getClass().getResource("/image/Order.png"));
        Icon click = new ImageIcon(getClass().getResource("/image/OrderC.png"));
        Icon en = new ImageIcon(getClass().getResource("/image/OrderEn.png"));
        
        if (uliconURL.equals(click.toString())) {
            System.out.println("Ok");
        } else {
            Oder.setIcon(normal);
        }
    }//GEN-LAST:event_OderMouseExited

    private void OderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OderMouseClicked
        Icon icon = new ImageIcon(getClass().getResource("/image/OrderC.png"));
        Oder.setIcon(icon);
        
        Icon P = new ImageIcon(getClass().getResource("/image/Purchase.png"));
        Icon S = new ImageIcon(getClass().getResource("/image/Supplier.png"));
        Purchase.setIcon(P);
        Supplier.setIcon(S);

        DefaultTableModel model = (DefaultTableModel) TableProduct.getModel();
        model.setRowCount(0); // เคลียร์ข้อมูลทั้งหมดใน JTable

        String fileData = ProductDB.readDataFromFile();
        String[] products = fileData.split("\n");

        for (String product : products) {
            String[] rowData = product.split(",");
            model.addRow(rowData); // เพิ่มแถวใหม่ลงใน JTable โดยใช้ข้อมูลใน rowData
        }
        ChangjPanel(true, false, false);
    }//GEN-LAST:event_OderMouseClicked
    public void UpdateSupplier(){
        DefaultTableModel model = (DefaultTableModel) TableSupplier.getModel();
        model.setRowCount(0); // เคลียร์ข้อมูลทั้งหมดใน JTable
        
        String fileData = SupplierDB.readDataFromFile();
        String[] products = fileData.split("\n");

        for (String product : products) {
            String[] rowData = product.split(",");
            model.addRow(rowData); // เพิ่มแถวใหม่ลงใน JTable โดยใช้ข้อมูลใน rowData
        }
    }
    private void SupplierMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SupplierMouseClicked
        Icon icon = new ImageIcon(getClass().getResource("/image/SupplierC.png"));
        Supplier.setIcon(icon);
        
        Icon P = new ImageIcon(getClass().getResource("/image/Purchase.png"));
        Icon O = new ImageIcon(getClass().getResource("/image/Order.png"));
        Icon Stock = new ImageIcon(getClass().getResource("/image/Stock.png"));

        Purchase.setIcon(P);
        Oder.setIcon(O);
        ChangjPanel(false, true, false);
        
        ScrollBarCustom sp = new ScrollBarCustom();
        sp.setOrientation(JScrollBar.HORIZONTAL);
        ScrollSupplier.setVerticalScrollBar(new ScrollBarCustom());
        ScrollSupplier.setHorizontalScrollBar(sp);
        ScrollSupplier.getViewport().setBackground(Color.WHITE);
        TableSupplier.getTableHeader().setFont(new Font("poppins", Font.BOLD, 12)); 
        TableCustom.apply(ScrollSupplier, TableCustom.TableType.MULTI_LINE);
        getContentPane().setBackground(Color.white);
        
        UpdateSupplier();
        
        TableActionEvent event = new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                System.out.println("Edit row : " + row);
                  int columnCount = TableSupplier.getColumnCount(); // หาจำนวนคอลัมน์ในตาราง
                  DefaultTableModel model = (DefaultTableModel) TableSupplier.getModel(); // ดึงโมเดลของตาราง
                  
                  Object name = model.getValueAt(row, 1);
                  Object  person  = model.getValueAt(row, 2);
                  Object tell = model.getValueAt(row, 3);
                  Object email = model.getValueAt(row, 4);
                  Object fax = model.getValueAt(row, 5);
                  Object address = model.getValueAt(row, 6);
                  
                  JDialogAddSupplier add = new JDialogAddSupplier(name.toString(), person.toString(), tell.toString(), email.toString(), fax.toString(), address.toString(), row+1);
                  add.setVisible(true);
                    }

                    @Override
                    public void onDelete(int row) {
                        if (TableSupplier.isEditing()) {
                            TableSupplier.getCellEditor().stopCellEditing();
                        }
        //                DefaultTableModel model = (DefaultTableModel) TableProduct.getModel();
        //                model.removeRow(row);
                        DefaultTableModel model = (DefaultTableModel) TableSupplier.getModel(); // ดึงโมเดลของตาราง

                            Object name = model.getValueAt(row, 1);
                            Object  person  = model.getValueAt(row, 2);
                            Object tell = model.getValueAt(row, 3);
                            Object email = model.getValueAt(row, 4);
                            Object fax = model.getValueAt(row, 5);
                            Object address = model.getValueAt(row, 6);

                        DialogDelect del = new DialogDelect(name.toString(), person.toString(), tell.toString(), email.toString(), fax.toString(), address.toString(), row);
                        del.setVisible(true);
                    }
                };
                TableSupplier.getColumnModel().getColumn(7).setCellRenderer(new TableActionCellRender());
                TableSupplier.getColumnModel().getColumn(7).setCellEditor(new TableActionCellEditor(event));
    }//GEN-LAST:event_SupplierMouseClicked
    
    public void AddProductPerchase(String nameProduct , String amount , String price , String detail){
        
        DefaultTableModel model = (DefaultTableModel) TablePurchase.getModel();
        int total = Integer.parseInt(price) * Integer.parseInt(amount) ;
        String[] rowData = { amount , nameProduct , detail , price , String.valueOf(total) };
        model.addRow(rowData);
        
        int calTotal = calculateTotal();
        int totalTax = (int) Math.round(calTotal * 7 / 100) + (calTotal);
        txtTotal.setText(String.valueOf(totalTax));
    }
    public int calculateTotal() {
        DefaultTableModel model = (DefaultTableModel) TablePurchase.getModel();
        int total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            int rowTotal = Integer.parseInt(model.getValueAt(i, 3).toString()) * Integer.parseInt(model.getValueAt(i, 0).toString());
            total += rowTotal;
        }

        return total;
    }
    private void PurchaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PurchaseMouseClicked
        Icon icon = new ImageIcon(getClass().getResource("/image/PurchaseC.png"));
        Purchase.setIcon(icon);
        
        Icon S = new ImageIcon(getClass().getResource("/image/Supplier.png"));
        Icon O = new ImageIcon(getClass().getResource("/image/Order.png"));
        Icon Stock = new ImageIcon(getClass().getResource("/image/Stock.png"));
        Supplier.setIcon(S);
        Oder.setIcon(O);

        ChangjPanel(false, false, true);
        ScrollBarCustom sp = new ScrollBarCustom();
        sp.setOrientation(JScrollBar.HORIZONTAL);
        ScrollPuschase.setVerticalScrollBar(new ScrollBarCustom());
        ScrollPuschase.setHorizontalScrollBar(sp);
        ScrollPuschase.getViewport().setBackground(Color.WHITE);
        
        jScrollcontact.setVerticalScrollBar(new ScrollBarCustom());
        jScrollcontact.setHorizontalScrollBar(sp);
        jScrollcontact.getViewport().setBackground(Color.WHITE);
        
        TablePurchase.getTableHeader().setFont(new Font("poppins", Font.BOLD, 12)); 
        TableCustom.apply(ScrollPuschase, TableCustom.TableType.MULTI_LINE);
        getContentPane().setBackground(Color.white);
        
        LocalDate date = LocalDate.now();
        this.date.setText(date.toString());
        
        dataSupplier.clear();
        try {
            File file = new File("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Supplier.txt");
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] rowData = line.split(",");
                List<String> row = Arrays.asList(rowData);
                List<String> formattedRow = new ArrayList<>();
                for (String item : row) {
                    formattedRow.add(item.trim());
                }
                dataSupplier.add(formattedRow);
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        // ตรวจสอบข้อมูลที่เก็บใน List<List<String>>
        for (List<String> row : dataSupplier) {
            System.out.println(row);
        }
        List<String> nameproduct = new ArrayList<>();
        for (List<String> row : dataSupplier) {
            if (row.size() > 1) { // ตรวจสอบว่ามีข้อมูลในคอลัมน์ที่ 2 หรือไม่
                nameproduct.add(row.get(1)); // เพิ่มข้อมูลจากคอลัมน์ที่ 2 ใน List
            }
        }
        
        combonameSupplier.removeAllItems();
        for (String columnTwoItem : nameproduct) {
            System.out.println(columnTwoItem);
            combonameSupplier.addItem(columnTwoItem);
        }
        combonameSupplier.addActionListener(e -> {
            int selectedIndex = combonameSupplier.getSelectedIndex();
            System.out.println("Selected index: " + selectedIndex);
            if (selectedIndex != -1) {
                selectSupplier(selectedIndex);
            } else {
                System.out.println("No item selected.");
            }
        });
        
         TableActionEvent event = new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                System.out.println("Edit row : " + row);
                  String warning = "Edit Product";
                  int columnCount = TablePurchase.getColumnCount(); // หาจำนวนคอลัมน์ในตาราง
                  DefaultTableModel model = (DefaultTableModel) TablePurchase.getModel(); // ดึงโมเดลของตาราง
                  Object Qty = model.getValueAt(row, 0);
                  Object  name  = model.getValueAt(row, 1);
                  Object detail = model.getValueAt(row, 2);
                  Object price = model.getValueAt(row, 3);    
                  JDialogAddpurchase edit = new JDialogAddpurchase(Qty.toString(), name.toString(), price.toString(), detail.toString(),row);
                  edit.setVisible(true);
            }
            @Override
            public void onDelete(int row) {
                if (TablePurchase.isEditing()) {
                    TablePurchase.getCellEditor().stopCellEditing();
                }
                DefaultTableModel model = (DefaultTableModel) TablePurchase.getModel();
                model.removeRow(row);
            }
        };
        TablePurchase.getColumnModel().getColumn(5).setCellRenderer(new TableActionCellRender());
        TablePurchase.getColumnModel().getColumn(5).setCellEditor(new TableActionCellEditor(event));
        
        discount.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                // กรณีมีการเพิ่มข้อมูลใน JTextField
                updateTotal();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                // กรณีมีการลบข้อมูลใน JTextField
                updateTotal();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // กรณีมีการเปลี่ยนแปลงในรูปแบบอื่น เช่น AttributeSet ใน StyledDocument
                updateTotal();
            }
        });
    }//GEN-LAST:event_PurchaseMouseClicked
 
    public  void updateTable(String Qty,String price,String nameproduct,String details,int row) {
       TablePurchase.setValueAt(Qty, row, 0);
       TablePurchase.setValueAt(nameproduct, row, 1);
       TablePurchase.setValueAt(details, row, 2);
       TablePurchase.setValueAt(price, row, 3);
       int total = Integer.parseInt(Qty) * Integer.parseInt(price) ;
       TablePurchase.setValueAt(total, row, 4);
    }
    public void updateTotal() {
        
        int calTotal = calculateTotal();
        int dis = Integer.parseInt(discount.getText());
        int totalTax = (int) Math.round(calTotal * 7 / 100) + (calTotal) - dis ;
        if (totalTax < 0){
            txtTotal.setText("0");
        } else {
           txtTotal.setText(String.valueOf(totalTax));
        }
   }
    public  void selectSupplier(int row){
          if (!dataSupplier.isEmpty()) {
            List<String> firstRow = dataSupplier.get(row); // ดึงข้อมูล row ที่ 0 จาก dataProduct

            if (firstRow.size() > 0) { // ตรวจสอบว่ามีข้อมูลในลิสต์นี้หรือไม่
                String contact = firstRow.get(2); // ดึงข้อมูลใน index ที่ 0 (ตัวแรก) ของ firstRow
                String Tell = firstRow.get(3); 
                String email = firstRow.get(4); 
                String fax = firstRow.get(5); 
                String Address = firstRow.get(6); 
                contactData.setText("Contact  Person : " + contact + "      Tell : " + Tell + "\n" + 
                        "Email : " + email + "     Fax : " + fax + "\n" +
                        "Address : " + Address 
                ); // เช่น ใส่ข้อมูลใน TextField
            }
        }
    }
    private void btnAddProductMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddProductMouseClicked
 
        String warning = "Add Product";
        JDialogAddEdit add = new JDialogAddEdit(this, rootPaneCheckingEnabled, warning);
        
        add.setVisible(true);
        
    }//GEN-LAST:event_btnAddProductMouseClicked

    private void btnAddsupplierMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddsupplierMouseClicked
        JDialogAddSupplier add = new JDialogAddSupplier(this, rootPaneCheckingEnabled);
        add.setVisible(true);
    }//GEN-LAST:event_btnAddsupplierMouseClicked

    private void NoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NoteActionPerformed

    private void ADDPURCHASEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ADDPURCHASEMouseClicked
        JDialogAddpurchase add = new JDialogAddpurchase(this, rootPaneCheckingEnabled);
        add.setVisible(true);
    }//GEN-LAST:event_ADDPURCHASEMouseClicked

    private void btnpurchaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnpurchaseMouseClicked
        PrintPDF print = new PrintPDF(TablePurchase,combonameSupplier.getSelectedItem().toString(),discount.getText(),Note.getText());
        print.setVisible(true);
    }//GEN-LAST:event_btnpurchaseMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainJimcom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainJimcom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainJimcom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainJimcom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                MainJimcom main = MainJimcom.getInstane();
                main.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ADDPURCHASE;
    private javax.swing.JLabel BGpurchase;
    private javax.swing.JLabel BGsupplier;
    private javax.swing.JLabel Bgorder;
    private javax.swing.JLabel Exit;
    private javax.swing.JPanel JPOrder;
    private javax.swing.JPanel JPPurchase;
    private javax.swing.JPanel JPSupplier;
    private javax.swing.JLabel Menu;
    private javax.swing.JTextField Note;
    private javax.swing.JLabel Oder;
    private javax.swing.JLabel Purchase;
    private javax.swing.JScrollPane ScrollProducts;
    private javax.swing.JScrollPane ScrollPuschase;
    private javax.swing.JScrollPane ScrollSupplier;
    private javax.swing.JLabel Supplier;
    private javax.swing.JTable TableProduct;
    private javax.swing.JTable TablePurchase;
    private javax.swing.JTable TableSupplier;
    private javax.swing.JPanel ZoneMenu;
    private javax.swing.JLabel btnAddProduct;
    private javax.swing.JLabel btnAddsupplier;
    private javax.swing.JLabel btnpurchase;
    private ComboboxClass.ComboBoxSuggestion combonameSupplier;
    private javax.swing.JTextArea contactData;
    private javax.swing.JLabel date;
    private javax.swing.JTextField discount;
    private javax.swing.JScrollPane jScrollcontact;
    private javax.swing.JLabel txtInclusive;
    private javax.swing.JLabel txtTotal;
    // End of variables declaration//GEN-END:variables

}
