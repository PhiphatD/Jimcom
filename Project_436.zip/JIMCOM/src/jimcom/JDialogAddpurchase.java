/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package jimcom;

import Java.ScrollBarCustom;
import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;

public class JDialogAddpurchase extends javax.swing.JDialog {
    private Integer row ;
    
    List<List<String>> dataProduct = new ArrayList<>();
    public JDialogAddpurchase(String amount , String name , String price , String detail, Integer rowin) {
        setUndecorated(true);
        initComponents();
        this.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        ScrollBarCustom sp = new ScrollBarCustom();
        sp.setOrientation(JScrollBar.HORIZONTAL);
        jScrollPane1.setVerticalScrollBar(new ScrollBarCustom());
        jScrollPane1.setHorizontalScrollBar(sp);
        jScrollPane1.getViewport().setBackground(Color.WHITE);
        Price.setText(price);
        Amount.setText(amount);
        ProductDetails.setText(detail);
        comboBoxProduct.setSelectedItem(name);
        
        this.row = rowin;
        
        try {
            File file = new File("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Products.txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] rowData = line.split(",");
                List<String> row = Arrays.asList(rowData);
                List<String> formattedRow = new ArrayList<>();
                for (String item : row) {
                    formattedRow.add(item.trim());
                }
                dataProduct.add(formattedRow);
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        // ตรวจสอบข้อมูลที่เก็บใน List<List<String>>
        for (List<String> row : dataProduct) {
            System.out.println(row);
        }
        List<String> nameproduct = new ArrayList<>();
        for (List<String> row : dataProduct) {
            if (row.size() > 1) { // ตรวจสอบว่ามีข้อมูลในคอลัมน์ที่ 2 หรือไม่
                nameproduct.add(row.get(1)); // เพิ่มข้อมูลจากคอลัมน์ที่ 2 ใน List
            }
        }
        for (String columnTwoItem : nameproduct) {
            System.out.println(columnTwoItem);
            comboBoxProduct.addItem(columnTwoItem);
        }
        comboBoxProduct.addActionListener(e -> {
            int selectedIndex = comboBoxProduct.getSelectedIndex();
            System.out.println("Selected index: " + selectedIndex);
            if (selectedIndex != -1) {
                selectData(selectedIndex);
            } else {
                System.out.println("No item selected.");
            }
             
        });
    }
    public JDialogAddpurchase(java.awt.Frame parent, boolean modal) {
        setUndecorated(true);
        initComponents();
        this.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        ScrollBarCustom sp = new ScrollBarCustom();
        sp.setOrientation(JScrollBar.HORIZONTAL);
        jScrollPane1.setVerticalScrollBar(new ScrollBarCustom());
        jScrollPane1.setHorizontalScrollBar(sp);
        jScrollPane1.getViewport().setBackground(Color.WHITE);
        
        try {
            File file = new File("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Products.txt");
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] rowData = line.split(",");
                List<String> row = Arrays.asList(rowData);
                List<String> formattedRow = new ArrayList<>();
                for (String item : row) {
                    formattedRow.add(item.trim());
                }
                dataProduct.add(formattedRow);
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        // ตรวจสอบข้อมูลที่เก็บใน List<List<String>>
        for (List<String> row : dataProduct) {
            System.out.println(row);
        }
        List<String> nameproduct = new ArrayList<>();
        for (List<String> row : dataProduct) {
            if (row.size() > 1) { // ตรวจสอบว่ามีข้อมูลในคอลัมน์ที่ 2 หรือไม่
                nameproduct.add(row.get(1)); // เพิ่มข้อมูลจากคอลัมน์ที่ 2 ใน List
            }
        }
        for (String columnTwoItem : nameproduct) {
            System.out.println(columnTwoItem);
            comboBoxProduct.addItem(columnTwoItem);
        }
        comboBoxProduct.addActionListener(e -> {
            int selectedIndex = comboBoxProduct.getSelectedIndex();
            System.out.println("Selected index: " + selectedIndex);
            if (selectedIndex != -1) {
                selectData(selectedIndex);
            } else {
                System.out.println("No item selected.");
            }
             
        });
    }
   public void selectData(int row) {
       if (!dataProduct.isEmpty()) {
            List<String> firstRow = dataProduct.get(row); // ดึงข้อมูล row ที่ 0 จาก dataProduct

            if (firstRow.size() > 0) { // ตรวจสอบว่ามีข้อมูลในลิสต์นี้หรือไม่
                String price = firstRow.get(2); // ดึงข้อมูลใน index ที่ 0 (ตัวแรก) ของ firstRow
                String details = firstRow.get(4); 
        Price.setText(price); // เช่น ใส่ข้อมูลใน TextField
        ProductDetails.setText(details);
            }
        }
   }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtWarning = new javax.swing.JLabel();
        btnCancel = new javax.swing.JLabel();
        btnComfirm = new javax.swing.JLabel();
        Amount = new javax.swing.JTextField();
        Price = new javax.swing.JTextField();
        comboBoxProduct = new ComboboxClass.ComboBoxSuggestion();
        Message = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ProductDetails = new javax.swing.JTextArea();
        BG = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtWarning.setFont(new java.awt.Font("Airbnb Cereal App Medium", 0, 20)); // NOI18N
        txtWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtWarning.setToolTipText("");
        getContentPane().add(txtWarning, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 230, 390, 40));

        btnCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pageOrder/cancelAdd.png"))); // NOI18N
        btnCancel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCancelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCancelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCancelMouseExited(evt);
            }
        });
        getContentPane().add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 560, 140, -1));

        btnComfirm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pageOrder/confirmAdd.png"))); // NOI18N
        btnComfirm.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnComfirm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnComfirmMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnComfirmMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnComfirmMouseExited(evt);
            }
        });
        getContentPane().add(btnComfirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 560, 140, -1));

        Amount.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        Amount.setToolTipText("");
        Amount.setBorder(null);
        Amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AmountActionPerformed(evt);
            }
        });
        getContentPane().add(Amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 366, 130, 17));

        Price.setEditable(false);
        Price.setBackground(new java.awt.Color(255, 255, 255));
        Price.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        Price.setToolTipText("");
        Price.setBorder(null);
        Price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceActionPerformed(evt);
            }
        });
        getContentPane().add(Price, new org.netbeans.lib.awtextra.AbsoluteConstraints(913, 367, 130, 17));

        comboBoxProduct.setBorder(null);
        getContentPane().add(comboBoxProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 309, 300, 19));

        Message.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        getContentPane().add(Message, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 570, 220, 20));

        jScrollPane1.setBorder(null);

        ProductDetails.setEditable(false);
        ProductDetails.setBackground(new java.awt.Color(255, 255, 255));
        ProductDetails.setColumns(20);
        ProductDetails.setRows(5);
        jScrollPane1.setViewportView(ProductDetails);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 430, 300, 70));

        BG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/supplier/dialogpurchase.png"))); // NOI18N
        getContentPane().add(BG, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 192, 390, 450));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pageOrder/opacity.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, 1260, 860));

        setSize(new java.awt.Dimension(1552, 869));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelMouseClicked
        dispose();
    }//GEN-LAST:event_btnCancelMouseClicked

    private void btnCancelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelMouseEntered
        Icon icon = new ImageIcon(getClass().getResource("/pageOrder/cancelAddEn.png"));
        btnCancel.setIcon(icon);
    }//GEN-LAST:event_btnCancelMouseEntered

    private void btnCancelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelMouseExited
        Icon icon = new ImageIcon(getClass().getResource("/pageOrder/cancelAdd.png"));
        btnCancel.setIcon(icon);
    }//GEN-LAST:event_btnCancelMouseExited

    private void btnComfirmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnComfirmMouseClicked
        if (row == null){
            MainJimcom.getInstane().AddProductPerchase( comboBoxProduct.getSelectedItem().toString() , Amount.getText() , Price.getText() , ProductDetails.getText());
            dispose();
        } else {
            dispose();
            MainJimcom.getInstane().updateTable(Amount.getText(),Price.getText(),comboBoxProduct.getSelectedItem().toString(),ProductDetails.getText(), row);
            MainJimcom.getInstane().updateTotal();
        }

    }//GEN-LAST:event_btnComfirmMouseClicked

    private void btnComfirmMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnComfirmMouseEntered
        Icon icon = new ImageIcon(getClass().getResource("/pageOrder/confirmAddEn.png"));
        btnComfirm.setIcon(icon);
    }//GEN-LAST:event_btnComfirmMouseEntered

    private void btnComfirmMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnComfirmMouseExited
        Icon icon = new ImageIcon(getClass().getResource("/pageOrder/confirmAdd.png"));
        btnComfirm.setIcon(icon);
    }//GEN-LAST:event_btnComfirmMouseExited

    private void PriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceActionPerformed

    }//GEN-LAST:event_PriceActionPerformed

    private void AmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AmountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AmountActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDialogAddpurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDialogAddpurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDialogAddpurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDialogAddpurchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDialogAddpurchase dialog = new JDialogAddpurchase(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Amount;
    private javax.swing.JLabel BG;
    private javax.swing.JLabel Message;
    private javax.swing.JTextField Price;
    private javax.swing.JTextArea ProductDetails;
    private javax.swing.JLabel btnCancel;
    private javax.swing.JLabel btnComfirm;
    private ComboboxClass.ComboBoxSuggestion comboBoxProduct;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel txtWarning;
    // End of variables declaration//GEN-END:variables
}
