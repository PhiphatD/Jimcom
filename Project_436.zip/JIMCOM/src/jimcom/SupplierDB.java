/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jimcom;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Mr.Phiphat
 */
public class SupplierDB {
    public static void Writedata(String SupplierName,String ContactPorson,String Tell,String Email,String Fax,String Address){
        try {
            File file = new File("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Supplier.txt");

            // ตรวจสอบว่าไฟล์มีอยู่หรือไม่
            if (!file.exists()) {
                file.createNewFile(); // ถ้าไม่มี สร้างไฟล์ใหม่
            }

            FileWriter fileWriter = new FileWriter(file, true); // true เพื่อให้เขียนต่อท้ายไฟล์เดิม
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            
            LocalDateTime date = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String formattedDate = date.format(formatter);

            // เขียนข้อมูลลงในไฟล์
            bufferedWriter.write(formattedDate + "," + SupplierName + "," + ContactPorson + "," + Tell + "," + Email + "," + Fax + "," + Address + System.lineSeparator());
            // ปิดการเขียนไฟล์
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static String readDataFromFile() {
       File file = new File("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Supplier.txt");
        StringBuilder fileContent = new StringBuilder();
        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                fileContent.append(line).append("\n"); // เก็บข้อมูลจากไฟล์
            }

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileContent.toString(); // ส่งข้อมูลที่อ่านได้กลับเป็น String
    }
    
    public static void deleteLine(int lineToRemove) {
        String filePath = ("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Supplier.txt");
        try {
            File inputFile = new File(filePath);
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            StringBuilder content = new StringBuilder();
            String line;
            int currentLine = 1;
            
            while ((line = reader.readLine()) != null) {
                if (currentLine != lineToRemove) {
                    content.append(line).append("\n");
                }
                currentLine++;
            }
            reader.close();

            // เขียนข้อมูลที่เหลือลงในไฟล์ใหม่
            BufferedWriter writer = new BufferedWriter(new FileWriter(inputFile));
            writer.write(content.toString());
            writer.close();

            System.out.println("ลบข้อมูลเรียบร้อยแล้ว");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void FileUpdate(String oldData,String newData,int Nline){       
        try {
            File file = new File("C:/Users/Mr.Phiphat/Desktop/Home work/Cs436/Project_JIMCOM/JIMCOM/src/jimcom/Supplier.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder content = new StringBuilder();
            String line;
            int lineNumber = 0;

            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (lineNumber == Nline) { 
                    // แยกข้อมูลในแต่ละคอลัมน์โดยใช้ ","
                    String[] columns = line.split(",");

                    // ทำการแก้ไขข้อมูลในแต่ละคอลัมน์ตามตำแหน่งที่ต้องการ
                    for (int i = 0; i < columns.length; i++) {
                        if (columns[i].equals(oldData)) {
                            columns[i] = newData;
                            }
                        }
                // นำข้อมูลที่แก้ไขแล้วมาประกอบกลับเป็นบรรทัดใหม่
                String updatedLine = String.join(",", columns);
                content.append(updatedLine).append("\n");
            } else {
                content.append(line).append("\n"); // ถ้าไม่ใช่บรรทัดที่ต้องการแก้ไขให้เก็บไว้เหมือนเดิม
                }
            }
            reader.close();

            // เขียนข้อมูลที่แก้ไขลงในไฟล์ใหม่
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(content.toString());
            writer.close();

            System.out.println("แก้ไขข้อมูลเรียบร้อยแล้ว");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
